"use client";
import {
  CardContent_default,
  cardContentClasses_default,
  getCardContentUtilityClass
} from "./chunk-2XFJMINV.js";
import "./chunk-TNSSMSDX.js";
import "./chunk-4JI2AD7N.js";
import "./chunk-CEQRFMJQ.js";
export {
  cardContentClasses_default as cardContentClasses,
  CardContent_default as default,
  getCardContentUtilityClass
};
//# sourceMappingURL=@mui_material_CardContent.js.map
