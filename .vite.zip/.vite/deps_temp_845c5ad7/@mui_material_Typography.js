"use client";
import {
  Typography_default,
  getTypographyUtilityClass,
  typographyClasses_default
} from "./chunk-QQST32G7.js";
import "./chunk-MUGAR6IQ.js";
import "./chunk-TNSSMSDX.js";
import "./chunk-4JI2AD7N.js";
import "./chunk-CEQRFMJQ.js";
export {
  Typography_default as default,
  getTypographyUtilityClass,
  typographyClasses_default as typographyClasses
};
//# sourceMappingURL=@mui_material_Typography.js.map
