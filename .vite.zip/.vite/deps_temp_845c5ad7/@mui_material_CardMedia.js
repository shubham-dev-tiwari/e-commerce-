"use client";
import {
  CardMedia_default,
  cardMediaClasses_default,
  getCardMediaUtilityClass
} from "./chunk-NEV65NH4.js";
import "./chunk-47G2SSUA.js";
import "./chunk-TNSSMSDX.js";
import "./chunk-4JI2AD7N.js";
import "./chunk-CEQRFMJQ.js";
export {
  cardMediaClasses_default as cardMediaClasses,
  CardMedia_default as default,
  getCardMediaUtilityClass
};
//# sourceMappingURL=@mui_material_CardMedia.js.map
