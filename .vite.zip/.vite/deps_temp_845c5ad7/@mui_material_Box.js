"use client";
import {
  Box_default,
  boxClasses_default
} from "./chunk-XRAC7J5A.js";
import "./chunk-6MMZT7ID.js";
import "./chunk-U6A4JVUB.js";
import "./chunk-VUFVWCCL.js";
import "./chunk-VQFPRD6A.js";
import "./chunk-47G2SSUA.js";
import "./chunk-TNSSMSDX.js";
import "./chunk-4JI2AD7N.js";
import "./chunk-CEQRFMJQ.js";
export {
  boxClasses_default as boxClasses,
  Box_default as default
};
//# sourceMappingURL=@mui_material_Box.js.map
