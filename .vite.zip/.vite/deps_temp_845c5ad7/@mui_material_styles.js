"use client";
import {
  CssVarsProvider,
  ThemeProvider,
  adaptV4Theme,
  createMuiStrictModeTheme,
  createStyles,
  excludeVariablesFromRoot_default,
  experimental_sx,
  extendTheme,
  getInitColorSchemeScript,
  getUnit,
  makeStyles,
  responsiveFontSizes,
  shouldSkipGeneratingVar,
  toUnitless,
  useColorScheme,
  withStyles,
  withTheme
} from "./chunk-6MMZT7ID.js";
import {
  getOverlayAlpha_default,
  useTheme
} from "./chunk-U6A4JVUB.js";
import {
  alpha,
  darken,
  decomposeColor,
  emphasize,
  getContrastRatio,
  getLuminance,
  hexToRgb,
  hslToRgb,
  lighten,
  recomposeColor,
  rgbToHex
} from "./chunk-VUFVWCCL.js";
import "./chunk-VQFPRD6A.js";
import "./chunk-47G2SSUA.js";
import {
  StyledEngineProvider,
  createMixins,
  createMuiTheme,
  createTheme_default2 as createTheme_default,
  createTypography,
  css,
  duration,
  easing,
  identifier_default,
  keyframes,
  styled_default,
  useThemeProps2 as useThemeProps
} from "./chunk-TNSSMSDX.js";
import "./chunk-4JI2AD7N.js";
import "./chunk-CEQRFMJQ.js";
export {
  CssVarsProvider as Experimental_CssVarsProvider,
  StyledEngineProvider,
  identifier_default as THEME_ID,
  ThemeProvider,
  adaptV4Theme,
  alpha,
  createMuiTheme,
  createStyles,
  createTheme_default as createTheme,
  css,
  darken,
  decomposeColor,
  duration,
  easing,
  emphasize,
  styled_default as experimentalStyled,
  extendTheme as experimental_extendTheme,
  experimental_sx,
  getContrastRatio,
  getInitColorSchemeScript,
  getLuminance,
  getOverlayAlpha_default as getOverlayAlpha,
  hexToRgb,
  hslToRgb,
  keyframes,
  lighten,
  makeStyles,
  createMixins as private_createMixins,
  createTypography as private_createTypography,
  excludeVariablesFromRoot_default as private_excludeVariablesFromRoot,
  recomposeColor,
  responsiveFontSizes,
  rgbToHex,
  shouldSkipGeneratingVar,
  styled_default as styled,
  createMuiStrictModeTheme as unstable_createMuiStrictModeTheme,
  getUnit as unstable_getUnit,
  toUnitless as unstable_toUnitless,
  useColorScheme,
  useTheme,
  useThemeProps,
  withStyles,
  withTheme
};
//# sourceMappingURL=@mui_material_styles.js.map
