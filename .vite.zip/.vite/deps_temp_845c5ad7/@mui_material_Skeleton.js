"use client";
import {
  Skeleton_default,
  getSkeletonUtilityClass,
  skeletonClasses_default
} from "./chunk-52EO5USL.js";
import "./chunk-6MMZT7ID.js";
import "./chunk-U6A4JVUB.js";
import "./chunk-VUFVWCCL.js";
import "./chunk-VQFPRD6A.js";
import "./chunk-47G2SSUA.js";
import "./chunk-TNSSMSDX.js";
import "./chunk-4JI2AD7N.js";
import "./chunk-CEQRFMJQ.js";
export {
  Skeleton_default as default,
  getSkeletonUtilityClass,
  skeletonClasses_default as skeletonClasses
};
//# sourceMappingURL=@mui_material_Skeleton.js.map
