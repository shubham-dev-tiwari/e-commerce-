import {
  init_useForkRef,
  useForkRef
} from "./chunk-VQFPRD6A.js";
import {
  __esm
} from "./chunk-CEQRFMJQ.js";

// node_modules/@mui/material/utils/useForkRef.js
var useForkRef_default;
var init_useForkRef2 = __esm({
  "node_modules/@mui/material/utils/useForkRef.js"() {
    "use client";
    init_useForkRef();
    useForkRef_default = useForkRef;
  }
});

export {
  useForkRef_default,
  init_useForkRef2 as init_useForkRef
};
//# sourceMappingURL=chunk-V73L5EQW.js.map
