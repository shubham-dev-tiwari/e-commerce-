import {
  capitalize,
  init_capitalize
} from "./chunk-TNSSMSDX.js";
import {
  __esm
} from "./chunk-CEQRFMJQ.js";

// node_modules/@mui/material/utils/capitalize.js
var capitalize_default;
var init_capitalize2 = __esm({
  "node_modules/@mui/material/utils/capitalize.js"() {
    init_capitalize();
    capitalize_default = capitalize;
  }
});

export {
  capitalize_default,
  init_capitalize2 as init_capitalize
};
//# sourceMappingURL=chunk-MUGAR6IQ.js.map
