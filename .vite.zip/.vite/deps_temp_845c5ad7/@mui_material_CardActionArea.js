"use client";
import {
  CardActionArea_default,
  cardActionAreaClasses_default,
  getCardActionAreaUtilityClass
} from "./chunk-LBQYTY2N.js";
import "./chunk-Q35CUS6U.js";
import "./chunk-WXSKVWTA.js";
import "./chunk-ODJE2LXE.js";
import "./chunk-V73L5EQW.js";
import "./chunk-VUFVWCCL.js";
import "./chunk-VQFPRD6A.js";
import "./chunk-47G2SSUA.js";
import "./chunk-TNSSMSDX.js";
import "./chunk-4JI2AD7N.js";
import "./chunk-CEQRFMJQ.js";
export {
  cardActionAreaClasses_default as cardActionAreaClasses,
  CardActionArea_default as default,
  getCardActionAreaUtilityClass
};
//# sourceMappingURL=@mui_material_CardActionArea.js.map
