import {
  require_react
} from "./chunk-4JI2AD7N.js";
import "./chunk-CEQRFMJQ.js";
export default require_react();
//# sourceMappingURL=react.js.map
