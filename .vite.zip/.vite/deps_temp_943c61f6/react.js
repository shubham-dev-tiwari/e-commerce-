import {
  require_react
} from "./chunk-UPTBV22B.js";
import "./chunk-Y2F7D3TJ.js";
export default require_react();
//# sourceMappingURL=react.js.map
